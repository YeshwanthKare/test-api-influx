const Influx = require("influx");
const dotenv = require('dotenv');

dotenv.config();

const influx = new Influx.InfluxDB({
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  username: process.env.DB_USER,
  password: process.env.DB_PASS,
  schema: [
    {
      measurement: "session",
      fields: { iccid: Influx.FieldType.INTEGER },
      tags: ["ADC_main", "ADC1", "ADC2", "ADC3", "ADC4", "ADC5", "ADC6"],
    },
  ],
});

module.exports = influx;